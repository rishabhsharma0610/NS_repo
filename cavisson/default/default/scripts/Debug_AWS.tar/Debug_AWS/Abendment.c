/*-----------------------------------------------------------------------------
    Name: Abendment
    Recorded By: Shashank
    Date of recording: 07/21/2020 03:59:38
    Flow details:
    Build details: 4.3.0 (build# 92)
    Modification History:
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

void Abendment()
{

ns_exit_session();

}
